package com.example.gridurl;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void img1(View v)
    {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/"));
        startActivity(i);
    }

    public void img2(View v)
    {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.amazon.in/"));
        startActivity(i);
    }

    public void img3(View v)
    {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.flipkart.com/"));
        startActivity(i);
    }

    public void img4(View v)
    {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.meesho.com/"));
        startActivity(i);
    }

}
