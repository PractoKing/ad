package com.example.railwayreg;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    EditText e1;
    Spinner spin;
    RadioGroup rG;
    RadioButton rb;
    CheckBox c1,c2,c3,c4;
    Button b1;

    String[] birth_ch = {"1999","2000","2001","2002"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1 = findViewById(R.id.text);
        spin = findViewById(R.id.spin);
        rG = findViewById(R.id.rg);

        c1 = findViewById(R.id.c1);
        c2 = findViewById(R.id.c2);
        c3 = findViewById(R.id.c3);
        c4 = findViewById(R.id.c4);

        b1 = findViewById(R.id.button);

        spin.setOnItemSelectedListener(this);
        ArrayAdapter<String> aa = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,birth_ch);
        aa.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spin.setAdapter(aa);

        b1.setOnClickListener(view -> {

            rb = findViewById(rG.getCheckedRadioButtonId());

            String name = e1.getText().toString();
            String birth = spin.getSelectedItem().toString();
            String city = rb.getText().toString();
            String meal = "";

            if(c1.isChecked())
            {
                meal = meal + c1.getText();
            }
            if(c2.isChecked())
            {
                meal = meal +"," + c2.getText();
            }
            if(c3.isChecked())
            {
                meal = meal +"," + c3.getText();
            }
            if(c4.isChecked())
            {
                meal = meal +"," + c4.getText();
            }
            String meal1 = meal;

            Bundle bundle =  new Bundle();
            bundle.putString("name",name);
            bundle.putString("birth",birth);
            bundle.putString("city",city);
            bundle.putString("meal",meal1);

            Intent i = new Intent(MainActivity.this,MainActivity2.class);
            i.putExtras(bundle);
            startActivity(i);
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        Toast.makeText(this, birth_ch[i], Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
