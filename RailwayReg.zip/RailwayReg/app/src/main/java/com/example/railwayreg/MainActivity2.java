package com.example.railwayreg;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    TextView t1,t2,t3,t4;
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        t1 = findViewById(R.id.txt1);
        t2 = findViewById(R.id.txt2);
        t3 = findViewById(R.id.txt3);
        t4 = findViewById(R.id.txt4);

        Bundle bundle = getIntent().getExtras();
        if(bundle!=null)
        {
            String name = bundle.getString("name");
            String birth = bundle.getString("birth");
            String city = bundle.getString("city");
            String meal = bundle.getString("meal");

            t1.setText("Name : " + name);
            t2.setText("Birth Choice : " + birth);
            t3.setText("City : " + city);
            t4.setText("Meal : " + meal);

        }
    }
}
