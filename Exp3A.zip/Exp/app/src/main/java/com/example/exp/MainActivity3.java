package com.example.exp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {
    TextView t1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        Intent hintent = getIntent();

        String fn =hintent.getStringExtra("fname");
        String ls = hintent.getStringExtra("lname");

        t1 = findViewById(R.id.textView5);
        t1.setText(fn +" "+ls);

    }
}