package com.example.exp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void showDetails(View view) {
        EditText fname = findViewById(R.id.fname);
        EditText lname = findViewById(R.id.lname);
        String fn = fname.getText().toString();
        String ln = lname.getText().toString();

        Intent int2 = new Intent(this ,MainActivity3.class);
        int2.putExtra("fname", fn);
        int2.putExtra("lname", ln);

        startActivity(int2);
    }
}