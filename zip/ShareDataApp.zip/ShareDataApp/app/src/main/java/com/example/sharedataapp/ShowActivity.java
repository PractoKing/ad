package com.example.sharedataapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
public class ShowActivity extends AppCompatActivity {
    private TextView tvName, tvMobile, tvStarter, tvMainCourse, tvDessert, tvDrink;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);
        tvName = findViewById(R.id.tvName);
        tvMobile = findViewById(R.id.tvMobile);
        tvStarter = findViewById(R.id.tvStarter);
        tvMainCourse = findViewById(R.id.tvMainCourse);
        tvDessert = findViewById(R.id.tvDessert);
        tvDrink = findViewById(R.id.tvDrink);
        Intent intent = getIntent();
        if (intent != null) {
            String name = intent.getStringExtra("name");
            String mobile = intent.getStringExtra("mobile");
            String starter = intent.getStringExtra("starter");
            String mainCourse = intent.getStringExtra("mainCourse");
            String dessert = intent.getStringExtra("dessert");
            String drink = intent.getStringExtra("drink");
            tvName.setText("Name: " + name);
            tvMobile.setText("Mobile: " + mobile);
            tvStarter.setText("Starter: " + starter);
            tvMainCourse.setText("Main Course: " + mainCourse);
            tvDessert.setText("Dessert: " + dessert);
            tvDrink.setText("Drink: " + drink);
        }
        Button btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}

