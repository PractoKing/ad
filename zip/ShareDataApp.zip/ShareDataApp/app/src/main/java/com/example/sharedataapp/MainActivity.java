package com.example.sharedataapp;

import android.content.Intent;
import android.os.Bundle;

import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText editName, editMobile, editStarter, editMainCourse, editDessert, editDrink;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editName = findViewById(R.id.editName);
        editMobile = findViewById(R.id.editMobile);
        editStarter = findViewById(R.id.editStarter);
        editMainCourse = findViewById(R.id.editMainCourse);
        editDessert = findViewById(R.id.editDessert);
        editDrink = findViewById(R.id.editDrink);
        Button btnSubmit = findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener(v -> {
            String name = editName.getText().toString();
            String mobile = editMobile.getText().toString();
            String starter = editStarter.getText().toString();
            String mainCourse = editMainCourse.getText().toString();
            String dessert = editDessert.getText().toString();
            String drink = editDrink.getText().toString();
            Intent intent = new Intent(MainActivity.this, ShowActivity.class);
            intent.putExtra("name", name);
            intent.putExtra("mobile", mobile);
            intent.putExtra("starter", starter);
            intent.putExtra("mainCourse", mainCourse);
            intent.putExtra("dessert", dessert);
            intent.putExtra("drink", drink);
            startActivity(intent);
        });
    }
}
