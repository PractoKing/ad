package com.example.a2activity2frag;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity2 extends AppCompatActivity {
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Button button1;
        button1=findViewById(R.id.button3);

        button1.setOnClickListener(v -> {
            Bundle bundle=new Bundle();
            Intent intent=getIntent();
            String name_inActivity2=intent.getStringExtra("name");
            String number_inActivity2=intent.getStringExtra("number");
            bundle.putString("name",name_inActivity2);
            bundle.putString("number",number_inActivity2);

            Fragment2 fragInfo = new Fragment2();
            fragInfo.setArguments(bundle);
            FragmentTransaction    transaction = getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.MainLayout1, fragInfo);
            transaction.commit();

        });
    }
}
