package com.example.a2activity2frag;
import android.os.Bundle;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
public class Fragment2 extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_2, container, false);
        TextView t1,t2;
        t1=view.findViewById(R.id.textView5);
        t2=view.findViewById(R.id.textView6);
        Bundle bundle=this.getArguments();
        if(bundle!=null){
            String name_inFragment=bundle.getString("name");
            String number_inFragment=bundle.getString("number");
            t1.setText(name_inFragment);
            t2.setText(number_inFragment);
        }

        return view;
    }
}
