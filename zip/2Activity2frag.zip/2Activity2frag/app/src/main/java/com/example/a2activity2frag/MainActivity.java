package com.example.a2activity2frag;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;



public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button; button=findViewById(R.id.button);
        button.setOnClickListener(v -> {
            FragmentTransaction fragmentTransaction=getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.MainLayout,new Fragment1());
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();
        });
    }

}
