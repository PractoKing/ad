package com.example.gridlayout;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void cricketClicked (View view) {
        Intent goToCricket = new Intent(MainActivity.this
                , cricket.class);
        startActivity(goToCricket);
    }
    public void footballClicked (View view) {
        Intent goToFootball = new Intent(MainActivity.this
                , Football.class);
        startActivity(goToFootball);
    }
    public void hockeyClicked (View view) {
        Intent goToHockey = new Intent(MainActivity.this
                , Hockey.class);
        startActivity(goToHockey);
    }
    public void tenisClicked (View view) {
        Intent goToTenis = new Intent(MainActivity.this
                , Tennis.class);
        startActivity(goToTenis);
    }
}
