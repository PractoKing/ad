package com.example.registrationform;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            String name = bundle.getString("name");
            String sub = bundle.getString("sub");
            String gen = bundle.getString("male");
            String qual = bundle.getString("SSC,HSC,BE/BTech,PG");

            TextView tvName = findViewById(R.id.textView4);
            TextView tvAge = findViewById(R.id.received_value_id);
            TextView tvgen = findViewById(R.id.textView5);
            TextView tvqual = findViewById(R.id.textView6);

            tvName.setText(name);
            tvAge.setText(sub);
            tvgen.setText(gen);
            tvqual.setText(qual);

        }
    }
}