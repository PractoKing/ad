package com.example.registrationform;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    EditText name;
    CheckBox bt1,bt2,bt3,bt4;
    RadioGroup rg;
    RadioButton rb;
    Button submit;
    String[] bankNames={"FOC","AD","DM","IAE","DBM"};

    @SuppressLint({"MissingInflatedId", "WrongViewCast"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name = findViewById(R.id.editTextTextPersonName);
        bt1= findViewById(R.id.checkBox);
        bt2= findViewById(R.id.checkBox2);
        bt3= findViewById(R.id.checkBox3);
        bt4= findViewById(R.id.checkBox4);
        submit = findViewById(R.id.button);
        Spinner spin = findViewById(R.id.spinner3);
        rg =  findViewById(R.id.radioGroup);
        //rb = findViewById(R.id.radioButton);

        spin.setOnItemSelectedListener(this);

        ArrayAdapter<String> aa = new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,bankNames);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(aa);

        submit.setOnClickListener(view -> {

            rb = (RadioButton)findViewById(rg.getCheckedRadioButtonId());
            String na = name.getText().toString().trim();
            String sub = spin.getSelectedItem().toString().trim();
            String gn = rb.getText().toString();
            String qu = "";

            if (bt1.isChecked()){
                qu = qu + " " + bt1.getText();
            }
            if (bt2.isChecked()){
                qu = qu + "," +  bt2.getText();
            }
            if (bt3.isChecked()){
                qu = qu + "," +  bt3.getText();
            }
            if (bt4.isChecked()){
                qu = qu + "," +  bt4.getText();
            }
            String q2 = qu;
            Bundle bundle = new Bundle();
            bundle.putString("name", na);
            bundle.putString("sub", sub);
            bundle.putString("male", gn);
            bundle.putString("SSC,HSC,BE/BTech,PG", q2);

            Intent i1 = new Intent(MainActivity.this, SecondActivity.class);
            i1.putExtras(bundle);
            startActivity(i1);
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {
        Toast.makeText(getApplicationContext(), bankNames[position], Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> arg0) {

    }
}