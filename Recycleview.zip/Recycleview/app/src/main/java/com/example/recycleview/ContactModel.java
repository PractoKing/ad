package com.example.recycleview;

public class ContactModel {
    String name,number;

    public ContactModel(String name,String number){
        this.name=name;
        this.number=number;

    }
}
