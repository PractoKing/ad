package com.example.recycleview;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<ContactModel> arrcontacts = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.myrecyc);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        arrcontacts.add(new ContactModel("Rohit","8825424736"));
        arrcontacts.add(new ContactModel("Ishan","7815336645"));
        arrcontacts.add(new ContactModel("Surya","9783120054"));
        arrcontacts.add(new ContactModel("Nehal","7772236569"));
        arrcontacts.add(new ContactModel("Tilak","9890080555"));
        arrcontacts.add(new ContactModel("Green","8862002179"));
        arrcontacts.add(new ContactModel("Tim David","8261841985"));
        arrcontacts.add(new ContactModel("Piyush","9545454789"));
        arrcontacts.add(new ContactModel("Kartikey","8421123854"));
        arrcontacts.add(new ContactModel("Jofra","8484972280"));
        arrcontacts.add(new ContactModel("Arjun","7351315411"));
        arrcontacts.add(new ContactModel("DB","8208308503"));
        arrcontacts.add(new ContactModel("bumraha","9890065563"));
        arrcontacts.add(new ContactModel("Sachin","722345548"));

        RecyclerContactAdapter adapter = new RecyclerContactAdapter(this, arrcontacts);
        recyclerView.setAdapter(adapter);
    }
}
