package com.example.webviewsameactivity;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText txt;
    Button b1;
    WebView web;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt = findViewById(R.id.txt1);
        b1= findViewById(R.id.button);
        web = findViewById(R.id.web);

        b1.setOnClickListener(view -> {
            String str = txt.getText().toString();
            web.setWebViewClient(new WebViewClient());
            web.loadUrl(str);
            WebSettings webSettings = web.getSettings();
            webSettings.setJavaScriptEnabled(true);
        });
    }
}
