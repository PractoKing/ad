package com.example.implicitexplicit;

import androidx.appcompat.app.AppCompatActivity; import
        android.content.Intent;
import android.net.Uri; import android.os.Bundle;
import android.view.View;
import android.widget.Button; import
        android.widget.EditText; import
        android.widget.LinearLayout; import android.widget.Toast;
public class MainActivity extends AppCompatActivity {
    Button expBtn , impBtn , sbtBtn ;
    EditText userName , userAge ; LinearLayout FormLayout ;
    boolean flag = false ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_main);
        expBtn = findViewById(R.id.expBtn); impBtn = findViewById(R.id.impBtn);
        sbtBtn = findViewById(R.id.sbtBtn); userName =
                findViewById(R.id.userName); userAge = findViewById(R.id.userAge);
        FormLayout = findViewById(R.id.FormLayout);
// Event Listener for Explicit Button
        expBtn.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) { if(flag==true){
            FormLayout.setVisibility(View.GONE); flag = false ;
            impBtn.setEnabled(true); }else{
            FormLayout.setVisibility(View.VISIBLE); flag = true ;
            impBtn.setEnabled(false); }
        } });
    // Event Listener for Submit Button
        sbtBtn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        String name = userName.getText().toString();
        int age = Integer.parseInt(userAge.getText().toString()); userName.getText().clear();
        userAge.getText().clear();
        Intent explicit_intent = new Intent(MainActivity.this, MainActivity2.class);
        explicit_intent.putExtra("USERNAME" , name);
        explicit_intent.putExtra("USERAGE" , age); startActivity(explicit_intent);
        FormLayout.setVisibility(View.GONE);
        flag = false ; impBtn.setEnabled(true);
        Toast.makeText(MainActivity.this, "Clicked Explicit Intent Button", Toast.LENGTH_SHORT)
                .show(); }
}); }
// Event Listener for Implicit Button
public void callImp(View view) {
        Intent implicit_intent = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:1234567890"));
        startActivity(implicit_intent);
        Toast.makeText(MainActivity.this, "Clicked Implicit Intent Button", Toast.LENGTH_SHORT)
        .show(); }
        }
