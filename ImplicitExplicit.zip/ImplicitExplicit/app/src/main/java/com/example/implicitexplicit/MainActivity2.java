package com.example.implicitexplicit;

import androidx.appcompat.app.AppCompatActivity; import android.content.Intent;
import android.os.Bundle; import android.widget.TextView;
public class MainActivity2 extends AppCompatActivity { TextView txtView ;
    @Override
    protected void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        txtView = findViewById(R.id.txtView); Intent HomeIntent = getIntent(); String
                receivedName =
                HomeIntent.getStringExtra("USERNAME");
        int receivedAge = HomeIntent.getIntExtra("USERAGE" , 0);
        String txt = "Hello !!" + receivedName + " You're " + receivedAge + " years Old" ;
        txtView.setText(txt); }
}
