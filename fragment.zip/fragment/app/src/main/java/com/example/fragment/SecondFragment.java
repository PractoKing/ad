package com.example.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class SecondFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        View rootView = inflater.inflate(R.layout.fragment_second,container,false);

        Bundle bundle = getArguments();

        assert bundle != null;
        String firstName = bundle.getString("FirstName");
        String lastName = bundle.getString("LastName");

        TextView firstText = (TextView) rootView.findViewById(R.id.firstname);
        TextView lastText = (TextView) rootView.findViewById(R.id.lastname);

        firstText.setText(firstName);
        lastText.setText(lastName);
        return rootView;
    }
}

